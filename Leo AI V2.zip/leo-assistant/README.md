# Leo AI Assistant

A bilingual (English + Hindi) desktop voice assistant powered by the **Groq LLM API**.
Calls you "Sir", opens apps, tells time/weather, takes notes, searches the web,
and holds smart conversations.

## Setup in PyCharm (Windows)

1. **Open the project**: In PyCharm, `File > Open` and select the `leo-assistant` folder.

2. **Create a virtual environment** (PyCharm usually offers this automatically):
   `File > Settings > Project > Python Interpreter > Add Interpreter > Virtualenv`

3. **Install dependencies** — open the PyCharm Terminal and run:
   ```
   pip install -r requirements.txt
   ```
   If `pyaudio` fails to install on Windows, run:
   ```
   pip install pipwin
   pipwin install pyaudio
   ```
   (Leo still works in text mode without pyaudio.)

4. **Add your Groq API key**:
   - Copy `.env.example` to a new file named `.env` (in the same folder as `main.py`)
   - Get a free key at https://console.groq.com/keys
   - Paste it in: `GROQ_API_KEY=gsk_xxxxxxxx`

5. **Run**: Right-click `main.py` > Run, or press the green Run button.

## Usage

| You say / type | Leo does |
| --- | --- |
| "open chrome" / "chrome kholo" | Opens the app |
| "what time is it" / "samay batao" | Tells the time |
| "weather in Delhi" / "mausam batao" | Fetches live weather |
| "play lo-fi music" / "gaana bajao" | Opens YouTube |
| "take a note buy milk" | Saves a note |
| "25 * 4 + 10" / "calculate 25 plus 5" | Does the math |
| "who is Elon Musk" | Smart LLM answer |
| "shutdown" / "restart" | Asks for confirmation first |
| "exit" / "band ho jao" | Quits Leo |

Anything Leo doesn't handle directly is answered by the Groq LLM
(`llama-3.3-70b-versatile` by default — change it via `GROQ_MODEL` in `.env`).

## Notes

- **Voice mode** activates automatically if a microphone is detected; otherwise Leo runs in text mode.
- Logs are saved to `data/logs/`, notes and todos to `data/memory.json`.
- Never commit your `.env` file — it's already in `.gitignore`.
