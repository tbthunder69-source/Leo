"""Leo AI Assistant - Time, date, notes, todos, simple calculations"""
import sys
import os
import re
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core import memory


def current_time(lang: str = "en") -> str:
    now = datetime.now().strftime("%I:%M %p")
    if lang == "hi":
        return f"Sir, abhi samay hai {now}."
    return f"Sir, the time is {now}."


def current_date(lang: str = "en") -> str:
    today = datetime.now().strftime("%d %B %Y, %A")
    if lang == "hi":
        return f"Sir, aaj ki tareekh hai {today}."
    return f"Sir, today is {today}."


def save_note(text: str, lang: str = "en") -> str:
    memory.add_note(text)
    if lang == "hi":
        return "Ji Sir, note save kar liya hai."
    return "Note saved, Sir."


def read_notes(lang: str = "en") -> str:
    notes = memory.get_notes()
    if not notes:
        return "Sir, koi note nahi mila." if lang == "hi" else "Sir, you have no notes yet."
    listed = ". ".join(f"{i+1}: {n}" for i, n in enumerate(notes[-5:]))
    if lang == "hi":
        return f"Sir, aapke notes: {listed}"
    return f"Here are your notes, Sir: {listed}"


def add_todo(text: str, lang: str = "en") -> str:
    memory.add_todo(text)
    if lang == "hi":
        return "Ji Sir, todo list mein daal diya."
    return "Added to your to-do list, Sir."


def read_todos(lang: str = "en") -> str:
    todos = memory.get_todos()
    if not todos:
        return "Sir, todo list khali hai." if lang == "hi" else "Sir, your to-do list is empty."
    listed = ". ".join(f"{i+1}: {t}" for i, t in enumerate(todos[-5:]))
    if lang == "hi":
        return f"Sir, aapki todo list: {listed}"
    return f"Your to-do list, Sir: {listed}"


def _safe_eval(expr: str):
    """Evaluate arithmetic using the ast module (no eval, fully safe)."""
    import ast
    import operator as op

    ops = {
        ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul,
        ast.Div: op.truediv, ast.Mod: op.mod, ast.Pow: op.pow,
        ast.USub: op.neg, ast.UAdd: op.pos,
    }

    def _eval(node):
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in ops:
            return ops[type(node.op)](_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in ops:
            return ops[type(node.op)](_eval(node.operand))
        raise ValueError("unsupported expression")

    return _eval(ast.parse(expr, mode="eval"))


def calculate(text: str, lang: str = "en") -> str:
    """Safely evaluate simple math like '25 * 4 + 10'."""
    # Convert spoken words to operators first
    t = text.lower()
    for word, symbol in [("plus", "+"), ("minus", "-"), ("times", "*"),
                         ("multiplied by", "*"), ("multiply", "*"),
                         ("divided by", "/"), ("divide", "/"), ("into", "*")]:
        t = t.replace(word, f" {symbol} ")
    expr = re.sub(r"[^0-9+\-*/(). %]", "", t).strip()
    if not expr or not re.search(r"\d", expr):
        return ""
    try:
        result = _safe_eval(expr)
        # Show clean integers (10.0 -> 10)
        if isinstance(result, float) and result.is_integer():
            result = int(result)
        elif isinstance(result, float):
            result = round(result, 4)
        if lang == "hi":
            return f"Sir, jawab hai {result}."
        return f"Sir, the answer is {result}."
    except Exception:
        return ""
