"""Leo AI Assistant - The Brain
1. Fast intent matching for direct commands (works offline).
2. Groq LLM fallback for open conversation, coding help, and anything else.
Returns the reply text — main.py speaks it.
"""
import re
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import GROQ_API_KEY, GROQ_MODEL, LLM_TEMPERATURE, LLM_MAX_TOKENS, LLM_TIMEOUT
from core import memory
from core.personality import SYSTEM_PROMPT, error_line
from skills import app_control, web_skills, productivity, file_manager
from utils.logger import log_error, log_info

# ---- Groq LLM (OpenAI-compatible API) ----
LLM_AVAILABLE = False
_client = None
if GROQ_API_KEY:
    try:
        from groq import Groq
        _client = Groq(api_key=GROQ_API_KEY)
        LLM_AVAILABLE = True
        log_info(f"Groq LLM ready (model: {GROQ_MODEL})")
    except ImportError:
        log_error("groq package not installed. Run: pip install groq")
    except Exception as e:
        log_error(f"Groq init failed: {e}")


def _contains(text, *words):
    return any(w in text for w in words)


def _has_word(text, *words):
    """Whole-word match to avoid false positives like 'open' inside 'happened'."""
    return any(re.search(rf"\b{re.escape(w)}\b", text) for w in words)


def _extract_after(text: str, triggers: list[str]) -> str:
    """Return the part of text after the first trigger phrase found, cleaned."""
    for trig in sorted(triggers, key=len, reverse=True):
        idx = text.find(trig)
        if idx != -1:
            return text[idx + len(trig):].strip(" ,.?!")
    return ""


def ask_llm(text: str, lang: str) -> str:
    """Ask Groq with conversation history. Returns '' on failure."""
    if not LLM_AVAILABLE:
        return ""
    try:
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend(memory.get_history())
        messages.append({"role": "user", "content": text})
        resp = _client.chat.completions.create(
            model=GROQ_MODEL,
            messages=messages,
            temperature=LLM_TEMPERATURE,
            max_tokens=LLM_MAX_TOKENS,
            timeout=LLM_TIMEOUT,
        )
        reply = (resp.choices[0].message.content or "").strip()
        return reply
    except Exception as e:
        log_error(f"Groq LLM error: {e}")
        return ""


def handle_command(text: str, lang: str, speak, listen) -> str:
    """Try direct intents first, then Groq LLM, then a friendly fallback."""
    t = text.lower().strip()

    # ---------- Open apps / websites ----------
    if _has_word(t, "open", "kholo", "chalu", "launch") or "start karo" in t:
        app = app_control.find_app(t)
        if app:
            ok = app_control.open_app(app)
            if ok:
                return (f"Ji Sir, {app} khol raha hoon." if lang == "hi"
                        else f"Opening {app}, Sir.")
            return error_line(lang)
        for site in ["youtube", "google", "gmail", "github", "instagram",
                     "facebook", "whatsapp", "twitter", "linkedin", "reddit",
                     "chatgpt", "netflix", "amazon", "flipkart"]:
            if site in t:
                app_control.open_website(f"{site}.com")
                return (f"Ji Sir, {site} khol raha hoon." if lang == "hi"
                        else f"Opening {site}, Sir.")

    # ---------- Time & Date ----------
    if _has_word(t, "time", "samay", "waqt", "baje"):
        return productivity.current_time(lang)
    if _has_word(t, "date", "tareekh") or "aaj ka din" in t or "today's day" in t:
        return productivity.current_date(lang)

    # ---------- Weather ----------
    if _has_word(t, "weather", "mausam", "temperature", "garmi", "sardi", "barish"):
        city = _extract_after(t, ["weather in", "weather of", "mausam in", "temperature in"])
        report = web_skills.get_weather(city)
        if report:
            return (f"Sir, mausam ka haal: {report}" if lang == "hi"
                    else f"Sir, here's the weather: {report}")
        return ("Sir, mausam ki jankari nahi mil payi." if lang == "hi"
                else "Sorry Sir, I couldn't fetch the weather right now.")

    # ---------- Web search / YouTube ----------
    if _has_word(t, "search", "dhundo", "khojo"):
        query = _extract_after(t, ["search for", "search", "dhundo", "khojo"])
        query = query.replace("google", "").replace("web par", "").strip()
        if query:
            web_skills.web_search(query)
            return (f"Ji Sir, '{query}' search kar raha hoon." if lang == "hi"
                    else f"Searching for '{query}', Sir.")
    if _has_word(t, "play", "bajao", "gaana", "song"):
        query = t
        for w in ["play", "bajao", "gaana", "song", "on youtube", "youtube par", "video"]:
            query = query.replace(w, "")
        query = query.strip() or "trending music"
        web_skills.play_on_youtube(query)
        return (f"Ji Sir, YouTube par '{query}' chala raha hoon." if lang == "hi"
                else f"Playing '{query}' on YouTube, Sir.")

    # ---------- Notes & Todos ----------
    if _contains(t, "note likho", "take a note", "note down", "note banao", "save note"):
        content = _extract_after(t, ["note likho", "take a note", "note down",
                                     "note banao", "save note"])
        content = content.removeprefix("that").strip()
        return productivity.save_note(content or "empty note", lang)
    if _contains(t, "read notes", "notes sunao", "notes padho", "my notes", "mere notes"):
        return productivity.read_notes(lang)
    if _contains(t, "todo", "to-do", "to do list", "kaam jodo"):
        if _has_word(t, "add", "jodo", "daalo", "likho"):
            content = _extract_after(t, ["add to todo", "add todo", "todo mein jodo",
                                         "add", "jodo", "daalo"])
            content = content.replace("todo", "").replace("to-do", "").strip()
            return productivity.add_todo(content or "task", lang)
        return productivity.read_todos(lang)

    # ---------- Calculations (only if it actually looks like math) ----------
    if re.search(r"\d", t) and (_has_word(t, "calculate", "plus", "minus", "multiply",
                                          "divide", "kitna hota hai")
                                or re.search(r"\d\s*[-+*/]\s*\d", t)):
        result = productivity.calculate(t, lang)
        if result:
            return result

    # ---------- Create folder / file ----------
    if _contains(t, "create folder", "folder banao", "new folder"):
        name = _extract_after(t, ["create folder", "folder banao", "new folder"])
        for w in ["named", "naam ka", "naam se", "called"]:
            name = name.replace(w, "")
        name = name.strip() or "New Folder by Leo"
        if file_manager.create_folder(name):
            return (f"Ji Sir, desktop par '{name}' folder bana diya." if lang == "hi"
                    else f"Created folder '{name}' on your desktop, Sir.")
        return error_line(lang)
    if _contains(t, "create file", "file banao", "new file"):
        name = _extract_after(t, ["create file", "file banao", "new file"])
        for w in ["named", "naam ka", "naam se", "called"]:
            name = name.replace(w, "")
        name = name.strip() or "leo_file"
        if file_manager.create_text_file(name):
            return (f"Ji Sir, desktop par '{name}' file bana di." if lang == "hi"
                    else f"Created file '{name}' on your desktop, Sir.")
        return error_line(lang)

    # ---------- Who are you ----------
    if _contains(t, "who are you", "tum kaun ho", "kaun ho tum", "your name", "tumhara naam"):
        return ("Sir, main Leo hoon — aapka personal AI assistant, dost aur coding partner!" if lang == "hi"
                else "I'm Leo, Sir — your personal AI assistant, friend, and coding partner!")

    # ---------- Groq LLM (conversation, coding, facts, everything else) ----------
    reply = ask_llm(text, lang)
    if reply:
        return reply

    # ---------- Wikipedia fallback for factual questions (no LLM) ----------
    if _contains(t, "who is", "what is", "kaun hai", "kya hai", "kya hota hai"):
        topic = _extract_after(t, ["who is", "what is", "kaun hai", "kya hai", "kya hota hai"])
        topic = topic.replace("batao", "").strip()
        if topic:
            summary = web_skills.wikipedia_summary(topic, lang)
            if summary:
                return f"Sir, {summary}"

    # ---------- Friendly fallback ----------
    if lang == "hi":
        return ("Sir, yeh mujhe abhi nahi aata. Apni Groq API key .env file mein daal kar "
                "mujhe aur smart banaiye! Filhaal main apps kholna, time, mausam, notes, "
                "search, aur calculations kar sakta hoon.")
    return ("Sir, I don't know that one yet. Add your Groq API key to the .env file to make "
            "me smarter! For now I can open apps, tell time and weather, take notes, "
            "search the web, and do calculations.")
