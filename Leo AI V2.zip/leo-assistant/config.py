"""Leo AI Assistant - Configuration
Loads settings from a .env file (place it next to this file) or system
environment variables. Works out of the box in PyCharm.
"""
import os

# ---- Load .env automatically (python-dotenv) ----
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
except ImportError:
    pass  # dotenv is optional; system env vars still work

ASSISTANT_NAME = "Leo"
USER_TITLE = "Sir"
WAKE_WORD = "leo"

# ---- Groq LLM (fast, free tier available at https://console.groq.com) ----
# Put your key in a .env file:  GROQ_API_KEY=gsk_xxxxxxxx
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "").strip()

# Recommended Groq models:
#   llama-3.3-70b-versatile  -> best quality (default)
#   llama-3.1-8b-instant     -> fastest replies
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")

# LLM generation settings
LLM_TEMPERATURE = 0.6
LLM_MAX_TOKENS = 512
LLM_TIMEOUT = 20  # seconds

# ---- Neural voices (edge-tts) - natural, human-like ----
VOICES = {
    "en": "en-IN-PrabhatNeural",   # Indian English male
    "hi": "hi-IN-MadhurNeural",    # Hindi male
}

# ---- Listening behaviour ----
LISTEN_TIMEOUT = 6        # seconds Leo waits for you to start speaking
PHRASE_TIME_LIMIT = 12    # max seconds per spoken command

# ---- Roman-Hindi words used to detect Hindi typed/spoken in English letters ----
HINDI_ROMAN_WORDS = {
    "kholo", "karo", "karna", "batao", "bataye", "bata", "kya", "hai", "hain",
    "kaise", "kyu", "kyun", "nahi", "haan", "han", "ji", "suno", "sunao",
    "chalu", "band", "kar", "do", "dijiye", "mujhe", "mera", "meri", "aap",
    "tum", "kaun", "kahan", "kab", "abhi", "gaana", "bajao", "likho", "padho",
    "samay", "waqt", "tareekh", "mausam", "khabar", "banao", "dikhao", "bolo",
    "chahiye", "raha", "rahi", "gaya", "gayi", "hoga", "hogi", "wala", "wali",
}
