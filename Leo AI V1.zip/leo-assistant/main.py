"""
Leo AI Assistant - Main Entry Point
Run:  python main.py

- Speaks and understands English AND Hindi (replies in your language)
- Calls you "Sir" with a warm, human personality
- Voice mode if microphone works; automatic text mode otherwise
- Say/type "exit", "quit", "band ho jao", or "so jao" to stop
- Destructive actions (shutdown/restart) always ask for confirmation
"""
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.listener import listen, detect_language, VOICE_AVAILABLE
from core.speaker import speak
from core import memory
from core.brain import handle_command
from core.personality import greeting, confused, error_line, goodbye
from skills import system_control
from utils.confirm import ask_confirmation
from utils.logger import log_info, log_error

EXIT_WORDS = ("exit", "quit", "goodbye", "bye leo", "band ho jao", "so jao", "alvida", "stop listening")


def contains_any(text, words):
    return any(w in text for w in words)


def handle_system_commands(text: str, lang: str) -> str | None:
    """Shutdown / restart / lock / sleep with confirmation. Returns reply or None."""
    t = text.lower()

    if contains_any(t, ["shutdown", "shut down", "band karo computer", "computer band", "pc band"]):
        if ask_confirmation(speak, listen, lang, "shut down the computer", "computer band kar doon"):
            system_control.shutdown_pc()
            return ("Ji Sir, computer 10 second mein band ho raha hai. Alvida!" if lang == "hi"
                    else "Shutting down in 10 seconds, Sir. Goodbye!")
        return "Theek hai Sir, cancel kar diya." if lang == "hi" else "Okay Sir, cancelled."

    if contains_any(t, ["restart", "reboot", "dobara chalu", "restart karo"]):
        if ask_confirmation(speak, listen, lang, "restart the computer", "computer restart kar doon"):
            system_control.restart_pc()
            return ("Ji Sir, computer 10 second mein restart ho raha hai." if lang == "hi"
                    else "Restarting in 10 seconds, Sir.")
        return "Theek hai Sir, cancel kar diya." if lang == "hi" else "Okay Sir, cancelled."

    if contains_any(t, ["lock", "lock karo", "computer lock"]):
        system_control.lock_pc()
        return "Ji Sir, computer lock kar diya." if lang == "hi" else "Locking the computer, Sir."

    if contains_any(t, ["sleep", "sula do", "sleep mode"]):
        if ask_confirmation(speak, listen, lang, "put the computer to sleep", "computer ko sleep mein daal doon"):
            system_control.sleep_pc()
            return "Ji Sir, sleep mode." if lang == "hi" else "Going to sleep mode, Sir."
        return "Theek hai Sir." if lang == "hi" else "Okay Sir."

    return None


def main():
    print("=" * 50)
    print("  LEO AI ASSISTANT")
    print("=" * 50)
    if VOICE_AVAILABLE:
        print("Microphone detected - VOICE MODE active. Speak to Leo!")
    else:
        print("No microphone / audio libs - TEXT MODE active. Type your commands.")
    print("Say or type 'exit' to quit.\n")

    speak(greeting("en"), "en")
    log_info("Leo started")

    while True:
        try:
            text = listen()
            if not text:
                continue

            lang = detect_language(text)

            # Exit
            if contains_any(text, EXIT_WORDS):
                speak(goodbye(lang), lang)
                log_info("Leo stopped by user")
                break

            # System commands (with confirmation)
            reply = handle_system_commands(text, lang)
            if reply:
                speak(reply, lang)
                if contains_any(text, ["shutdown", "shut down", "band karo computer"]):
                    break
                continue

            # Everything else -> brain
            reply = handle_command(text, lang, speak, listen)
            if reply:
                speak(reply, lang)
                memory.add_exchange(text, reply)
            else:
                speak(confused(lang), lang)

        except KeyboardInterrupt:
            speak(goodbye("en"), "en")
            break
        except Exception as e:
            log_error(f"Main loop error: {e}")
            try:
                speak(error_line("en"), "en")
            except Exception:
                print(f"Leo error: {e}")


if __name__ == "__main__":
    main()
