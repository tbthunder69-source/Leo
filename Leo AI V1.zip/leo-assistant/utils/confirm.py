"""Leo AI Assistant - Safety confirmation before destructive actions"""

YES_WORDS = {"yes", "yeah", "yep", "sure", "ok", "okay", "confirm", "haan", "han", "ha", "ji", "ji haan", "bilkul", "kar do", "karo"}
NO_WORDS = {"no", "nope", "cancel", "stop", "nahi", "nahin", "mat", "ruko", "rehne do"}


def is_yes(text: str) -> bool:
    text = text.lower().strip()
    return any(w in text for w in YES_WORDS) and not any(w in text for w in NO_WORDS)


def ask_confirmation(speak, listen, lang: str, action_en: str, action_hi: str) -> bool:
    """Ask user to confirm. Returns True only on explicit yes."""
    if lang == "hi":
        speak(f"Sir, kya aap sure hain ki main {action_hi}? Haan ya nahi boliye.", "hi")
    else:
        speak(f"Sir, are you sure you want me to {action_en}? Please say yes or no.", "en")

    answer = listen() or ""
    return is_yes(answer)
