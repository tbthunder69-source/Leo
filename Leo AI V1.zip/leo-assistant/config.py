"""Leo AI Assistant - Configuration"""
import os

ASSISTANT_NAME = "Leo"
USER_TITLE = "Sir"
WAKE_WORD = "leo"

# Optional: set your OpenAI API key as an environment variable OPENAI_API_KEY
# for smart LLM answers. Leo works fine without it too.
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL = "gpt-4o-mini"

# Neural voices (edge-tts) - natural, human-like
VOICES = {
    "en": "en-IN-PrabhatNeural",   # Indian English male
    "hi": "hi-IN-MadhurNeural",    # Hindi male
}

# How long Leo listens for a command (seconds)
LISTEN_TIMEOUT = 6
PHRASE_TIME_LIMIT = 10

# Roman-Hindi words used to detect Hindi typed/spoken in English letters
HINDI_ROMAN_WORDS = {
    "kholo", "karo", "karna", "batao", "bataye", "bata", "kya", "hai", "hain",
    "kaise", "kyu", "kyun", "nahi", "haan", "han", "ji", "suno", "sunao",
    "chalu", "band", "kar", "do", "dijiye", "mujhe", "mera", "meri", "aap",
    "tum", "kaun", "kahan", "kab", "abhi", "gaana", "bajao", "likho", "padho",
    "samay", "waqt", "tareekh", "mausam", "khabar", "banao", "dikhao", "bolo",
}
