"""Leo AI Assistant - Speech to Text + Language Detection
Falls back to keyboard input automatically if microphone is unavailable.
"""
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import LISTEN_TIMEOUT, PHRASE_TIME_LIMIT, HINDI_ROMAN_WORDS
from utils.logger import log_info, log_error

# Try to load speech recognition; if anything fails, use text mode.
VOICE_AVAILABLE = True
try:
    import speech_recognition as sr
    _recognizer = sr.Recognizer()
    _recognizer.energy_threshold = 300
    _recognizer.dynamic_energy_threshold = True
    _recognizer.pause_threshold = 0.8
    # Verify a microphone actually exists
    try:
        _mics = sr.Microphone.list_microphone_names()
        if not _mics:
            VOICE_AVAILABLE = False
    except Exception:
        VOICE_AVAILABLE = False
except Exception:
    VOICE_AVAILABLE = False


def detect_language(text: str) -> str:
    """Detect Hindi vs English. Devanagari script OR common roman-Hindi words -> hi."""
    if not text:
        return "en"
    # Devanagari unicode range
    for ch in text:
        if "\u0900" <= ch <= "\u097F":
            return "hi"
    words = set(text.lower().split())
    if len(words & HINDI_ROMAN_WORDS) >= 1:
        return "hi"
    return "en"


def listen() -> str:
    """Listen from mic (or keyboard fallback). Returns lowercase text ('' if nothing)."""
    if not VOICE_AVAILABLE:
        try:
            return input("You (type your command): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return "exit"

    try:
        with sr.Microphone() as source:
            _recognizer.adjust_for_ambient_noise(source, duration=0.5)
            print("Listening...")
            audio = _recognizer.listen(source, timeout=LISTEN_TIMEOUT, phrase_time_limit=PHRASE_TIME_LIMIT)

        # Try Hindi first (also recognizes English words), then English
        text = ""
        try:
            text = _recognizer.recognize_google(audio, language="hi-IN")
        except Exception:
            try:
                text = _recognizer.recognize_google(audio, language="en-IN")
            except Exception:
                return ""

        text = text.strip().lower()
        print(f"You said: {text}")
        log_info(f"Heard: {text}")
        return text

    except sr.WaitTimeoutError:
        return ""
    except Exception as e:
        log_error(f"Listen error: {e}")
        return ""
