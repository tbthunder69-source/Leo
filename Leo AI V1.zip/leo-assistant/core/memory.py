"""Leo AI Assistant - Conversation memory (short-term list + long-term JSON)"""
import json
import os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
os.makedirs(DATA_DIR, exist_ok=True)
MEMORY_FILE = os.path.join(DATA_DIR, "memory.json")

MAX_HISTORY = 10  # exchanges sent to the LLM for context

_history = []  # [{"role": "user"/"assistant", "content": "..."}]


def add_exchange(user_text: str, assistant_text: str):
    _history.append({"role": "user", "content": user_text})
    _history.append({"role": "assistant", "content": assistant_text})
    # keep only recent context
    while len(_history) > MAX_HISTORY * 2:
        _history.pop(0)


def get_history():
    return list(_history)


# ---------- Long-term memory (notes, todos, facts) ----------

def _load() -> dict:
    try:
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"notes": [], "todos": [], "facts": {}}


def _save(data: dict):
    try:
        with open(MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def add_note(text: str):
    data = _load()
    data.setdefault("notes", []).append(text)
    _save(data)


def get_notes():
    return _load().get("notes", [])


def add_todo(text: str):
    data = _load()
    data.setdefault("todos", []).append(text)
    _save(data)


def get_todos():
    return _load().get("todos", [])
