"""Leo AI Assistant - The Brain
1. Fast intent matching for direct commands (works offline).
2. Optional LLM fallback (OpenAI) for open conversation, if OPENAI_API_KEY is set.
Returns: (reply_text, handled_bool) — main.py speaks the reply.
"""
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import OPENAI_API_KEY, OPENAI_MODEL
from core import memory
from core.personality import SYSTEM_PROMPT, ack, done, error_line
from skills import app_control, web_skills, productivity, file_manager
from utils.logger import log_error

# Optional LLM
LLM_AVAILABLE = False
if OPENAI_API_KEY:
    try:
        from openai import OpenAI
        _client = OpenAI(api_key=OPENAI_API_KEY)
        LLM_AVAILABLE = True
    except Exception:
        LLM_AVAILABLE = False


def _contains(text, *words):
    return any(w in text for w in words)


def handle_command(text: str, lang: str, speak, listen) -> str:
    """Try direct intents first, then LLM, then a friendly fallback."""
    t = text.lower().strip()

    # ---------- Open apps ----------
    if _contains(t, "open", "kholo", "chalu", "start karo", "launch"):
        app = app_control.find_app(t)
        if app:
            ok = app_control.open_app(app)
            if ok:
                return (f"Ji Sir, {app} khol raha hoon." if lang == "hi"
                        else f"Opening {app}, Sir.")
            return error_line(lang)
        # open a website?
        for site in ["youtube", "google", "gmail", "github", "instagram", "facebook", "whatsapp"]:
            if site in t:
                app_control.open_website(f"{site}.com")
                return (f"Ji Sir, {site} khol raha hoon." if lang == "hi"
                        else f"Opening {site}, Sir.")

    # ---------- Time & Date ----------
    if _contains(t, "time", "samay", "waqt", "baje"):
        return productivity.current_time(lang)
    if _contains(t, "date", "tareekh", "aaj ka din", "today's day"):
        return productivity.current_date(lang)

    # ---------- Weather ----------
    if _contains(t, "weather", "mausam", "temperature", "garmi", "sardi", "barish"):
        report = web_skills.get_weather()
        if report:
            return (f"Sir, mausam ka haal: {report}" if lang == "hi"
                    else f"Sir, here's the weather: {report}")
        return ("Sir, mausam ki jankari nahi mil payi." if lang == "hi"
                else "Sorry Sir, I couldn't fetch the weather right now.")

    # ---------- Web search / YouTube ----------
    if _contains(t, "search", "dhundo", "khojo"):
        query = t
        for w in ["search for", "search", "google", "dhundo", "khojo", "web par"]:
            query = query.replace(w, "")
        query = query.strip()
        if query:
            web_skills.web_search(query)
            return (f"Ji Sir, '{query}' search kar raha hoon." if lang == "hi"
                    else f"Searching for '{query}', Sir.")
    if _contains(t, "play", "bajao", "gaana", "song", "video"):
        query = t
        for w in ["play", "bajao", "gaana", "song", "on youtube", "youtube par", "video"]:
            query = query.replace(w, "")
        query = query.strip() or "trending music"
        web_skills.play_on_youtube(query)
        return (f"Ji Sir, YouTube par '{query}' chala raha hoon." if lang == "hi"
                else f"Playing '{query}' on YouTube, Sir.")

    # ---------- Notes & Todos ----------
    if _contains(t, "note likho", "take a note", "note down", "note banao", "save note"):
        content = t
        for w in ["note likho", "take a note", "note down", "note banao", "save note", "that"]:
            content = content.replace(w, "")
        return productivity.save_note(content.strip() or "empty note", lang)
    if _contains(t, "read notes", "notes sunao", "notes padho", "my notes", "mere notes"):
        return productivity.read_notes(lang)
    if _contains(t, "todo", "to-do", "to do list", "kaam jodo"):
        if _contains(t, "add", "jodo", "daalo", "likho"):
            content = t
            for w in ["add to todo", "add todo", "todo mein jodo", "todo", "add", "jodo", "daalo"]:
                content = content.replace(w, "")
            return productivity.add_todo(content.strip() or "task", lang)
        return productivity.read_todos(lang)

    # ---------- Calculations ----------
    if _contains(t, "calculate", "kitna hota hai", "plus", "minus", "multiply", "divide", "+", "-", "*", "/"):
        result = productivity.calculate(t, lang)
        if result:
            return result

    # ---------- Create folder / file ----------
    if _contains(t, "create folder", "folder banao", "new folder"):
        name = t
        for w in ["create folder", "folder banao", "new folder", "named", "naam ka", "naam se"]:
            name = name.replace(w, "")
        name = name.strip() or "New Folder by Leo"
        if file_manager.create_folder(name):
            return (f"Ji Sir, desktop par '{name}' folder bana diya." if lang == "hi"
                    else f"Created folder '{name}' on your desktop, Sir.")
        return error_line(lang)
    if _contains(t, "create file", "file banao", "new file"):
        name = t
        for w in ["create file", "file banao", "new file", "named", "naam ka", "naam se"]:
            name = name.replace(w, "")
        name = name.strip() or "leo_file"
        if file_manager.create_text_file(name):
            return (f"Ji Sir, desktop par '{name}' file bana di." if lang == "hi"
                    else f"Created file '{name}' on your desktop, Sir.")
        return error_line(lang)

    # ---------- Who are you ----------
    if _contains(t, "who are you", "tum kaun ho", "kaun ho tum", "your name", "tumhara naam"):
        return ("Sir, main Leo hoon — aapka personal AI assistant, dost aur coding partner!" if lang == "hi"
                else "I'm Leo, Sir — your personal AI assistant, friend, and coding partner!")

    # ---------- Wikipedia-style factual question ----------
    if _contains(t, "who is", "what is", "kaun hai", "kya hai", "kya hota hai"):
        topic = t
        for w in ["who is", "what is", "kaun hai", "kya hai", "kya hota hai", "batao"]:
            topic = topic.replace(w, "")
        topic = topic.strip()
        if topic and not LLM_AVAILABLE:
            summary = web_skills.wikipedia_summary(topic, lang)
            if summary:
                return f"Sir, {summary}"

    # ---------- LLM fallback (conversation, coding help, everything else) ----------
    if LLM_AVAILABLE:
        try:
            messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            messages.extend(memory.get_history())
            messages.append({"role": "user", "content": text})
            resp = _client.chat.completions.create(model=OPENAI_MODEL, messages=messages)
            return resp.choices[0].message.content.strip()
        except Exception as e:
            log_error(f"LLM error: {e}")

    # ---------- Friendly fallback ----------
    if lang == "hi":
        return ("Sir, yeh mujhe abhi nahi aata. Aap mujhe OpenAI API key dekar aur bhi smart bana sakte hain! "
                "Filhaal main apps kholna, time, mausam, notes, search, aur calculations kar sakta hoon.")
    return ("Sir, I don't know that one yet. You can make me smarter by adding an OpenAI API key! "
            "For now I can open apps, tell time and weather, take notes, search the web, and do calculations.")
