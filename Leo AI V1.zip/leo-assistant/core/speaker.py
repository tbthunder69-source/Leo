"""Leo AI Assistant - Text to Speech (human-like)
Priority: edge-tts (neural voices) -> pyttsx3 (offline) -> print only.
Never crashes: always at least prints the reply.
"""
import sys
import os
import asyncio
import tempfile

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import VOICES
from utils.logger import log_error

# --- Try edge-tts + pygame for playback ---
EDGE_AVAILABLE = True
try:
    import edge_tts
    import pygame
    pygame.mixer.init()
except Exception:
    EDGE_AVAILABLE = False

# --- Fallback: pyttsx3 (offline) ---
PYTTSX3_AVAILABLE = True
try:
    import pyttsx3
except Exception:
    PYTTSX3_AVAILABLE = False


def _speak_edge(text: str, lang: str) -> bool:
    try:
        voice = VOICES.get(lang, VOICES["en"])

        async def _gen(path):
            tts = edge_tts.Communicate(text, voice)
            await tts.save(path)

        tmp = os.path.join(tempfile.gettempdir(), "leo_reply.mp3")
        asyncio.run(_gen(tmp))

        pygame.mixer.music.load(tmp)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
        pygame.mixer.music.unload()
        return True
    except Exception as e:
        log_error(f"edge-tts failed: {e}")
        return False


def _speak_pyttsx3(text: str) -> bool:
    try:
        engine = pyttsx3.init()
        engine.setProperty("rate", 175)
        engine.say(text)
        engine.runAndWait()
        engine.stop()
        return True
    except Exception as e:
        log_error(f"pyttsx3 failed: {e}")
        return False


def speak(text: str, lang: str = "en"):
    """Speak the text out loud. Always prints it too."""
    print(f"Leo: {text}")
    if EDGE_AVAILABLE and _speak_edge(text, lang):
        return
    if PYTTSX3_AVAILABLE and _speak_pyttsx3(text):
        return
    # Text-only fallback already printed above
