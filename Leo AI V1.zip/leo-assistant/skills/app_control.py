"""Leo AI Assistant - Open Windows applications"""
import os
import subprocess
import webbrowser
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.logger import log_info, log_error

# App name -> command / executable
APPS = {
    "chrome": "chrome",
    "edge": "msedge",
    "notepad": "notepad",
    "calculator": "calc",
    "paint": "mspaint",
    "spotify": "spotify",
    "file explorer": "explorer",
    "explorer": "explorer",
    "command prompt": "cmd",
    "cmd": "cmd",
    "powershell": "powershell",
    "task manager": "taskmgr",
    "settings": "ms-settings:",
    "control panel": "control",
    "vs code": "code",
    "vscode": "code",
    "visual studio code": "code",
    "word": "winword",
    "excel": "excel",
}

# Hindi keywords -> app key
HINDI_APP_WORDS = {
    "chrome": "chrome", "krome": "chrome",
    "notepad": "notepad",
    "calculator": "calculator", "kelkuletar": "calculator",
    "paint": "paint",
    "spotify": "spotify",
    "explorer": "file explorer",
    "settings": "settings",
    "code": "vs code",
}


def find_app(text: str):
    text = text.lower()
    for name in sorted(APPS.keys(), key=len, reverse=True):
        if name in text:
            return name
    for word, key in HINDI_APP_WORDS.items():
        if word in text:
            return key
    return None


def open_app(app_name: str) -> bool:
    cmd = APPS.get(app_name)
    if not cmd:
        return False
    try:
        if cmd.startswith("ms-settings"):
            os.system(f"start {cmd}")
        elif os.name == "nt":
            os.system(f"start {cmd}")
        else:
            subprocess.Popen([cmd])
        log_info(f"Opened app: {app_name}")
        return True
    except Exception as e:
        log_error(f"Failed to open {app_name}: {e}")
        return False


def open_website(url: str) -> bool:
    try:
        if not url.startswith("http"):
            url = "https://" + url
        webbrowser.open(url)
        return True
    except Exception as e:
        log_error(f"Failed to open website {url}: {e}")
        return False
