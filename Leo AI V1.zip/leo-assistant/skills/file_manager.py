"""Leo AI Assistant - File management (create folders/files on Desktop)"""
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.logger import log_info, log_error


def desktop_path() -> str:
    return os.path.join(os.path.expanduser("~"), "Desktop")


def create_folder(name: str) -> bool:
    try:
        path = os.path.join(desktop_path(), name)
        os.makedirs(path, exist_ok=True)
        log_info(f"Created folder: {path}")
        return True
    except Exception as e:
        log_error(f"Create folder failed: {e}")
        return False


def create_text_file(name: str, content: str = "") -> bool:
    try:
        if not name.endswith(".txt"):
            name += ".txt"
        path = os.path.join(desktop_path(), name)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        log_info(f"Created file: {path}")
        return True
    except Exception as e:
        log_error(f"Create file failed: {e}")
        return False
