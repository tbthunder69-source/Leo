"""Leo AI Assistant - Time, date, notes, todos, simple calculations"""
import sys
import os
import re
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core import memory


def current_time(lang: str = "en") -> str:
    now = datetime.now().strftime("%I:%M %p")
    if lang == "hi":
        return f"Sir, abhi samay hai {now}."
    return f"Sir, the time is {now}."


def current_date(lang: str = "en") -> str:
    today = datetime.now().strftime("%d %B %Y, %A")
    if lang == "hi":
        return f"Sir, aaj ki tareekh hai {today}."
    return f"Sir, today is {today}."


def save_note(text: str, lang: str = "en") -> str:
    memory.add_note(text)
    if lang == "hi":
        return "Ji Sir, note save kar liya hai."
    return "Note saved, Sir."


def read_notes(lang: str = "en") -> str:
    notes = memory.get_notes()
    if not notes:
        return "Sir, koi note nahi mila." if lang == "hi" else "Sir, you have no notes yet."
    listed = ". ".join(f"{i+1}: {n}" for i, n in enumerate(notes[-5:]))
    if lang == "hi":
        return f"Sir, aapke notes: {listed}"
    return f"Here are your notes, Sir: {listed}"


def add_todo(text: str, lang: str = "en") -> str:
    memory.add_todo(text)
    if lang == "hi":
        return "Ji Sir, todo list mein daal diya."
    return "Added to your to-do list, Sir."


def read_todos(lang: str = "en") -> str:
    todos = memory.get_todos()
    if not todos:
        return "Sir, todo list khali hai." if lang == "hi" else "Sir, your to-do list is empty."
    listed = ". ".join(f"{i+1}: {t}" for i, t in enumerate(todos[-5:]))
    if lang == "hi":
        return f"Sir, aapki todo list: {listed}"
    return f"Your to-do list, Sir: {listed}"


def calculate(text: str, lang: str = "en") -> str:
    """Safely evaluate simple math like '25 * 4 + 10'."""
    expr = re.sub(r"[^0-9+\-*/(). ]", "", text)
    if not expr.strip():
        return ""
    try:
        result = eval(expr, {"__builtins__": {}}, {})  # sanitized: digits/operators only
        if lang == "hi":
            return f"Sir, jawab hai {result}."
        return f"Sir, the answer is {result}."
    except Exception:
        return ""
