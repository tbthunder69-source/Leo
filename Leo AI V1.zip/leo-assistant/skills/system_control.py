"""Leo AI Assistant - System control (Windows). All destructive actions need confirmation."""
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.logger import log_info, log_error


def lock_pc() -> bool:
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.LockWorkStation()
            log_info("PC locked")
            return True
        return False
    except Exception as e:
        log_error(f"Lock failed: {e}")
        return False


def shutdown_pc() -> bool:
    try:
        if os.name == "nt":
            os.system("shutdown /s /t 10")
            log_info("Shutdown initiated")
            return True
        return False
    except Exception as e:
        log_error(f"Shutdown failed: {e}")
        return False


def restart_pc() -> bool:
    try:
        if os.name == "nt":
            os.system("shutdown /r /t 10")
            log_info("Restart initiated")
            return True
        return False
    except Exception as e:
        log_error(f"Restart failed: {e}")
        return False


def sleep_pc() -> bool:
    try:
        if os.name == "nt":
            os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
            return True
        return False
    except Exception as e:
        log_error(f"Sleep failed: {e}")
        return False


def cancel_shutdown() -> bool:
    try:
        if os.name == "nt":
            os.system("shutdown /a")
            return True
        return False
    except Exception:
        return False
