"""Leo AI Assistant - Internet skills: web search, websites, weather (no API key), wikipedia"""
import webbrowser
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.logger import log_error

try:
    import requests
    REQUESTS_OK = True
except Exception:
    REQUESTS_OK = False


def web_search(query: str) -> bool:
    try:
        webbrowser.open(f"https://www.google.com/search?q={query.replace(' ', '+')}")
        return True
    except Exception as e:
        log_error(f"Search failed: {e}")
        return False


def play_on_youtube(query: str) -> bool:
    try:
        webbrowser.open(f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}")
        return True
    except Exception as e:
        log_error(f"YouTube failed: {e}")
        return False


def get_weather(city: str = "") -> str:
    """Free weather via wttr.in - no API key needed."""
    if not REQUESTS_OK:
        return ""
    try:
        url = f"https://wttr.in/{city}?format=%l:+%C,+%t,+humidity+%h"
        r = requests.get(url, timeout=8)
        if r.status_code == 200:
            return r.text.strip()
        return ""
    except Exception as e:
        log_error(f"Weather failed: {e}")
        return ""


def wikipedia_summary(topic: str, lang: str = "en") -> str:
    if not REQUESTS_OK:
        return ""
    try:
        code = "hi" if lang == "hi" else "en"
        url = f"https://{code}.wikipedia.org/api/rest_v1/page/summary/{topic.replace(' ', '_')}"
        r = requests.get(url, timeout=8)
        if r.status_code == 200:
            data = r.json()
            return data.get("extract", "")[:500]
        return ""
    except Exception as e:
        log_error(f"Wikipedia failed: {e}")
        return ""
